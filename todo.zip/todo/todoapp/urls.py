from todoapp import views
from django.urls import path


urlpatterns=[
path('',views.alltodos,name='alltodos'),
path('delete_item/<int:pk>',views.deleteItem,name = 'deleteItem'),
path('update_item/<int:pk>',views.updateItem,name = 'updateItem'),

]
