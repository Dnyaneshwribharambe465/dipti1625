from django.contrib import admin
from .models import Mytodo
# Register your models here.
admin.site.register(Mytodo)
